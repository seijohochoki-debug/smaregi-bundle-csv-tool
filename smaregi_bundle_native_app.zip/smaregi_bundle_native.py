# -*- coding: utf-8 -*-
"""
スマレジ バンドル販売 CSV登録ツール
ネイティブアプリ版（ユーザーアクセストークン / PKCE）

標準ライブラリのみ。
Python 3.10+ 推奨。

注意:
- スマレジDEVのネイティブアプリに登録したクライアントIDを使用します。
- リダイレクトURIは urn:ietf:wg:oauth:2.0:oob を固定。
- OOB方式のため、ブラウザで認証後に表示された認可コードをアプリへ貼り付けます。
- client secret は使用しません。
"""

import base64
import csv
import hashlib
import json
import os
import secrets
import string
import time
import tkinter as tk
import webbrowser
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob"
SCOPES = "pos.products:read pos.products:write offline_access"

ENV = {
    "開発環境": {
        "id_base": "https://id.smaregi.dev",
        "api_base": "https://api.smaregi.dev",
        "client_id": "5fa0479874599f34d5a570167c9a25c9",
    },
    "本番環境": {
        "id_base": "https://id.smaregi.jp",
        "api_base": "https://api.smaregi.jp",
        "client_id": "f3ed8ba84750c2c73ffb8324781aa709",
    },
}

TOKEN_FILE = os.path.join(os.path.expanduser("~"), ".smaregi_bundle_token.json")


def http_json(method, url, headers=None, data=None, form=False):
    headers = dict(headers or {})
    if form:
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif data is not None:
        headers["Content-Type"] = "application/json"
    req = Request(url, method=method, headers=headers)
    if data is not None:
        if form:
            body = urlencode(data).encode("utf-8")
        else:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        req.data = body
    try:
        with urlopen(req, timeout=30) as r:
            raw = r.read().decode("utf-8")
            return r.status, (json.loads(raw) if raw else {})
    except HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            body = json.loads(raw)
        except Exception:
            body = {"detail": raw}
        raise RuntimeError(f"HTTP {e.code}: {body}")
    except URLError as e:
        raise RuntimeError(f"通信エラー: {e.reason}")


def make_pkce():
    alphabet = string.ascii_letters + string.digits + "-._~"
    verifier = "".join(secrets.choice(alphabet) for _ in range(64))
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def save_token(env_name, token):
    token["_saved_at"] = int(time.time())
    token["_env"] = env_name
    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
        json.dump(token, f, ensure_ascii=False)


def load_token(env_name):
    if not os.path.exists(TOKEN_FILE):
        return None
    try:
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            t = json.load(f)
        if t.get("_env") != env_name:
            return None
        return t
    except Exception:
        return None


def refresh_token(env_name, refresh):
    e = ENV[env_name]
    status, data = http_json(
        "POST",
        e["id_base"] + "/authorize/token",
        data={
            "grant_type": "refresh_token",
            "refresh_token": refresh,
        },
        form=True,
    )
    save_token(env_name, data)
    return data


def get_access_token(env_name):
    t = load_token(env_name)
    if not t:
        return None
    # アクセストークン期限は変更され得るため、期限の5分前を目安に更新
    saved = int(t.get("_saved_at", 0))
    expires = int(t.get("expires_in", 0))
    if t.get("access_token") and (expires <= 0 or time.time() < saved + expires - 300):
        return t["access_token"]
    if t.get("refresh_token"):
        try:
            nt = refresh_token(env_name, t["refresh_token"])
            return nt.get("access_token")
        except Exception:
            return None
    return None


def exchange_code(env_name, code, verifier):
    e = ENV[env_name]
    status, data = http_json(
        "POST",
        e["id_base"] + "/authorize/token",
        data={
            "grant_type": "authorization_code",
            "code": code.strip(),
            "redirect_uri": REDIRECT_URI,
            "code_verifier": verifier,
        },
        form=True,
    )
    save_token(env_name, data)
    return data


def api_request(env_name, contract_id, token, method, path, data=None, query=None):
    e = ENV[env_name]
    url = e["api_base"] + "/" + contract_id.strip() + "/pos/" + path.lstrip("/")
    if query:
        url += "?" + urlencode(query)
    status, body = http_json(
        method,
        url,
        headers={"Authorization": "Bearer " + token},
        data=data,
    )
    return body


def resolve_category(env_name, contract_id, token, code):
    body = api_request(
        env_name, contract_id, token, "GET", "categories",
        query={"category_code": str(code).strip(), "limit": "100"},
    )
    if not isinstance(body, list):
        raise RuntimeError(f"部門コード {code}: 想定外のAPI応答")
    matches = [x for x in body if str(x.get("categoryCode", "")) == str(code).strip()]
    if len(matches) == 0:
        raise RuntimeError(f"部門コード {code} が見つかりません。")
    if len(matches) > 1:
        raise RuntimeError(f"部門コード {code} が複数見つかりました。")
    return str(matches[0]["categoryId"]), str(matches[0].get("categoryName", ""))


def build_payload(row, category_id):
    type_map = {
        "販売価格": "1",
        "値引額": "2",
        "割引率": "3",
        "1": "1", "2": "2", "3": "3"
    }
    typ = type_map.get(row["方式"].strip())
    if not typ:
        raise ValueError("方式は「販売価格」「値引額」「割引率」のいずれかです。")

    quantity = int(row["個数"])
    value = int(row["金額"])
    if not (1 <= quantity <= 999):
        raise ValueError("個数は1～999です。")
    if typ == "3" and not (0 <= value <= 100):
        raise ValueError("割引率は0～100です。")

    tax_div = str(row.get("税区分", "0") or "0").strip()
    point_na = str(row.get("ポイント対象外", "0") or "0").strip()
    tax_free = str(row.get("免税区分", "0") or "0").strip()
    calc_discount = str(row.get("値引割引計算対象", "1") or "1").strip()

    if tax_div not in ("0", "1", "2"):
        raise ValueError("税区分は0/1/2です。")
    if point_na not in ("0", "1"):
        raise ValueError("ポイント対象外は0/1です。")
    if tax_free not in ("0", "1", "2"):
        raise ValueError("免税区分は0/1/2です。")
    if calc_discount not in ("0", "1"):
        raise ValueError("値引割引計算対象は0/1です。")

    # reduceTaxValueは「税区分に応じた軽減税率適用時の値」。
    # CSVで空欄ならvalueと同じ値を入れる。
    reduce_value = str(row.get("軽減税率適用時金額", "") or "").strip()
    if not reduce_value:
        reduce_value = str(value)

    payload = {
        "productBundleGroupName": row["バンドル名称"].strip(),
        "type": typ,
        "taxDivision": tax_div,
        "quantity": str(quantity),
        "value": str(value),
        "reduceTaxValue": reduce_value,
        "priority": str(int(row.get("優先順位", "1") or "1")),
        "termFrom": row["開始日"].strip(),
        "termTo": row["終了日"].strip(),
        "pointNotApplicable": point_na,
        "taxFreeDivision": tax_free,
        "calcDiscount": calc_discount,
        "products": [{"categoryId": str(category_id)}],
    }

    reduce_tax_id = str(row.get("軽減税率ID", "") or "").strip()
    if reduce_tax_id:
        payload["reduceTaxId"] = reduce_tax_id
    return payload


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("スマレジ バンドル販売 CSV登録ツール")
        self.geometry("1050x760")
        self.verifier = None
        self.state = None
        self.rows = []
        self._build()

    def _build(self):
        p = ttk.Frame(self, padding=12)
        p.pack(fill="both", expand=True)

        ttk.Label(p, text="環境").grid(row=0, column=0, sticky="w", pady=4)
        self.env = ttk.Combobox(p, values=list(ENV.keys()), state="readonly", width=18)
        self.env.set("開発環境")
        self.env.grid(row=0, column=1, sticky="w")
        self.env.bind("<<ComboboxSelected>>", lambda e: self._show_client())

        ttk.Label(p, text="クライアントID").grid(row=1, column=0, sticky="w", pady=4)
        self.client = ttk.Entry(p, width=48)
        self.client.grid(row=1, column=1, sticky="w")
        self._show_client()

        ttk.Label(p, text="契約ID").grid(row=2, column=0, sticky="w", pady=4)
        self.contract = ttk.Entry(p, width=48)
        self.contract.grid(row=2, column=1, sticky="w")
        ttk.Label(p, text="開発環境では sb_ から始まる契約IDを入力").grid(row=2, column=2, sticky="w")

        auth = ttk.LabelFrame(p, text="スマレジ認証", padding=8)
        auth.grid(row=3, column=0, columnspan=3, sticky="ew", pady=10)
        ttk.Button(auth, text="① スマレジ認証画面を開く", command=self.start_auth).grid(row=0, column=0, padx=5)
        ttk.Label(auth, text="② 認証後に表示された認可コードを貼り付け").grid(row=0, column=1, padx=5)
        self.code = ttk.Entry(auth, width=55)
        self.code.grid(row=1, column=0, columnspan=2, padx=5, pady=6, sticky="ew")
        ttk.Button(auth, text="③ 認可コードを送信", command=self.finish_auth).grid(row=1, column=2, padx=5)
        self.auth_status = ttk.Label(auth, text="未認証")
        self.auth_status.grid(row=2, column=0, columnspan=3, sticky="w", padx=5)

        ttk.Label(p, text="CSV").grid(row=4, column=0, sticky="w")
        ttk.Button(p, text="CSVを選択", command=self.load_csv).grid(row=4, column=1, sticky="w")
        self.file_label = ttk.Label(p, text="未選択")
        self.file_label.grid(row=4, column=2, sticky="w")

        self.dry = tk.BooleanVar(value=True)
        ttk.Checkbutton(p, text="ドライラン（登録しない）", variable=self.dry).grid(row=5, column=1, sticky="w", pady=6)

        self.text = tk.Text(p, height=23, wrap="none")
        self.text.grid(row=6, column=0, columnspan=3, sticky="nsew")

        buttons = ttk.Frame(p)
        buttons.grid(row=7, column=0, columnspan=3, sticky="e", pady=8)
        ttk.Button(buttons, text="CSV内容を確認", command=self.validate_csv).pack(side="left", padx=4)
        ttk.Button(buttons, text="バンドル登録実行", command=self.run).pack(side="left", padx=4)
        ttk.Button(buttons, text="終了", command=self.destroy).pack(side="left", padx=4)

        p.columnconfigure(2, weight=1)
        p.rowconfigure(6, weight=1)

    def _show_client(self):
        e = ENV[self.env.get()]
        self.client.delete(0, "end")
        self.client.insert(0, e["client_id"])
        self.auth_status.config(text="未認証")

    def start_auth(self):
        env = self.env.get()
        client_id = self.client.get().strip()
        if not client_id:
            messagebox.showwarning("入力不足", "クライアントIDがありません。")
            return
        self.verifier, challenge = make_pkce()
        self.state = secrets.token_urlsafe(24)
        params = {
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": REDIRECT_URI,
            "scope": SCOPES,
            "state": self.state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }
        url = ENV[env]["id_base"] + "/authorize?" + urlencode(params)
        webbrowser.open(url)
        self.auth_status.config(text="ブラウザで認証してください。認証後、表示された認可コードを下欄へ貼り付けます。")

    def finish_auth(self):
        if not self.verifier:
            messagebox.showwarning("認証開始前", "先に「スマレジ認証画面を開く」を押してください。")
            return
        code = self.code.get().strip()
        if not code:
            messagebox.showwarning("認可コード未入力", "認可コードを貼り付けてください。")
            return
        try:
            token = exchange_code(self.env.get(), code, self.verifier)
            if not token.get("access_token"):
                raise RuntimeError(str(token))
            self.auth_status.config(text="認証済み。アクセストークンを保存しました。")
            messagebox.showinfo("認証成功", "スマレジAPIへの接続準備ができました。")
        except Exception as e:
            messagebox.showerror("認証エラー", str(e))

    def load_csv(self):
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                required = ["部門コード", "バンドル名称", "個数", "方式", "金額", "開始日", "終了日"]
                missing = [x for x in required if x not in (reader.fieldnames or [])]
                if missing:
                    raise ValueError("CSVに必要な列がありません: " + ", ".join(missing))
                self.rows = list(reader)
            self.file_label.config(text=os.path.basename(path))
            self.validate_csv()
        except Exception as e:
            messagebox.showerror("CSVエラー", str(e))

    def validate_csv(self):
        if not self.rows:
            return
        self.text.delete("1.0", "end")
        for i, r in enumerate(self.rows, 1):
            self.text.insert(
                "end",
                f"{i}: 部門={r['部門コード']} / {r['バンドル名称']} / "
                f"{r['個数']}個 / {r['方式']} / {r['金額']} / "
                f"{r['開始日']}～{r['終了日']}\n"
            )
        self.text.insert("end", f"\n合計 {len(self.rows)} 行\n")

    def run(self):
        if not self.rows:
            messagebox.showwarning("CSV未選択", "先にCSVを選択してください。")
            return
        env = self.env.get()
        contract = self.contract.get().strip()
        token = get_access_token(env)
        if not contract:
            messagebox.showwarning("契約ID未入力", "契約IDを入力してください。")
            return
        if not token:
            messagebox.showwarning("未認証", "先にスマレジ認証を行ってください。")
            return

        results, errors = [], []
        for i, row in enumerate(self.rows, 1):
            try:
                category_id, category_name = resolve_category(
                    env, contract, token, row["部門コード"]
                )
                payload = build_payload(row, category_id)

                if self.dry.get():
                    results.append(
                        f"行{i}: 確認OK / 部門 {row['部門コード']} → ID {category_id} "
                        f"({category_name}) / 登録なし"
                    )
                else:
                    body = api_request(env, contract, token, "POST", "bundles", payload)
                    gid = body.get("productBundleGroupId", "?")
                    results.append(
                        f"行{i}: 登録成功 / バンドルID={gid} / "
                        f"部門 {row['部門コード']} → ID {category_id}"
                    )
            except Exception as e:
                errors.append(f"行{i}: {e}")

        self.text.delete("1.0", "end")
        self.text.insert("end", "\n".join(results))
        if errors:
            self.text.insert("end", "\n\n--- エラー ---\n" + "\n".join(errors))
            messagebox.showwarning("処理完了（一部エラー）",
                                   f"正常: {len(results)} / エラー: {len(errors)}")
        else:
            messagebox.showinfo("処理完了", f"{len(results)} 行処理しました。")


if __name__ == "__main__":
    App().mainloop()
