スマレジ バンドル販売 CSV登録ツール（ネイティブアプリ版）
================================================

今回の版はスマレジ・プラットフォームAPIのネイティブアプリ方式を前提にしています。

■ スマレジDEVの設定
開発環境:
- クライアントID: アプリの環境設定に表示されるもの
- リダイレクトURI: urn:ietf:wg:oauth:2.0:oob

本番環境:
- クライアントID: アプリの環境設定に表示されるもの
- リダイレクトURI: urn:ietf:wg:oauth:2.0:oob

コードには今回提示された開発/本番のクライアントIDを初期値として入れています。
クライアントIDは秘密情報ではありません。クライアントシークレットは使用しません。

■ 必要なAPIスコープ
pos.products:read
pos.products:write
offline_access

■ 認証
1. アプリで「スマレジ認証画面を開く」
2. ブラウザでスマレジへログインし、アプリを認可
3. OOB画面に表示された認可コードをコピー
4. アプリへ貼り付け
5. 「認可コードを送信」
6. PKCEでアクセストークンを取得
7. offline_accessが許可されればリフレッシュトークンも保存

アクセストークン等はユーザーのホームフォルダの
.smaregi_bundle_token.json
に保存します。本番PCではこのファイルを他人に渡さないでください。

■ API
開発: https://api.smaregi.dev/{契約ID}/pos/...
本番: https://api.smaregi.jp/{契約ID}/pos/...

■ バンドル販売
CSVの「方式」
販売価格 → type=1
値引額   → type=2
割引率   → type=3

部門コードは GET /categories?category_code=... で検索し、
返された categoryId を POST /bundles の products[].categoryId に設定します。

■ 重要
最初は「ドライラン（登録しない）」で実行してください。
本番環境で登録する前に開発環境（サンドボックス）で確認してください。

■ アプリURLについて
スマレジDEVの「アプリのURL」は、このPCアプリをユーザーが取得/インストールするための
公開URLです。このZIPそのものには公開URLはありません。
例えば自社サイトやGitHub Releases等にWindows版インストーラー/ZIPを公開し、
その配布ページURLを登録します。

■ EXE化
PyInstaller等でexe化できます。
例:
pyinstaller --onefile --windowed smaregi_bundle_native.py

生成された dist/smaregi_bundle_native.exe を配布用に公開してください。
