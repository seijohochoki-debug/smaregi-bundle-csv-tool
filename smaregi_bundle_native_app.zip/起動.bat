﻿@echo off
chcp 65001 > nul
python smaregi_bundle_native.py
pause
